#define Npmax 10000
//    Npmax     : Maximum Number Of Particles
