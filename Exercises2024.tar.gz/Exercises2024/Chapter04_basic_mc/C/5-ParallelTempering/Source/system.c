#include "system.h"

VECTOR Positions[NUMBEROFPARTICLES][MAXNUMBEROFSYSTEMS];
double Uold[MAXNUMBEROFSYSTEMS];

double Box;
int NumberOfSystems;
