#include "system.h"

int Lattice[MAX_LATTICE][MAX_LATTICE];
position Particle[MAX_PARTICLES];
int Mxx[MAX_PARTICLES];
int Myy[MAX_PARTICLES];
int NumberOfParticles;

