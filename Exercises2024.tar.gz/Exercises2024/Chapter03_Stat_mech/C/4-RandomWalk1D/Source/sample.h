enum{INITIALIZE,START_NEW_WALK,SAMPLE_WALK,WRITE_RESULTS};
void Sample(int Switch, int CurrentPosition);
