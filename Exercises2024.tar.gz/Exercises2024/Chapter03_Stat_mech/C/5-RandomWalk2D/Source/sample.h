enum{INITIALIZE,SAMPLE_WALK,WRITE_RESULTS};
void Sample(int Switch);
