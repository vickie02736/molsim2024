#include "system_2.h"
extern double Box[2],Hbox[2],Temp,Beta;

//extern double /Sys1/,Box[2],Hbox[2],Temp,Beta;
//C
//C     Box      : Simulation Box Length
//C     Hbox     : 0.5 * Box
//C     Temp     : Temperature
//C     Beta     : 1/Temp
