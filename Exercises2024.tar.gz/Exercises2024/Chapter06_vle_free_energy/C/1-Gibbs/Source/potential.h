extern double  Eps4,Eps48,Sig2,Mass,Rc[2],Rc2[2];
//extern double /Pot1/ Eps4,Eps48,Sig2,Mass,Rc[2],Rc2[2];
//  Eps4      : 4 * Epsilon 
//  Eps48     : 48 * Epsilon
//  (Epsilon) : Energy Parameter Lennard-Jones Potential
//  Sig2      : Sigma*Sigma
//  (Sigma)   : Size Parameter Lennard-Jones Potenital
//  Mass      : Mass Of The Molecules
//  Rc        : Cut-Off Radius Of The Potenial
//  Rc2       : Rc * Rc
