#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "system.h"
#include "ran_uniform.h"

// integrate the equations of motion for the Andersen thermostat
void IntegrateAndersen(void)
{
  double U,F;

  // start modification

  // end modification
}
